# Your answer for Task 3: How
![first hypothesis](/images/hypothesis1 primary fur color frequency1.png)
![first hypothesis2](/images/hypothesis1-1Highlight Fur Color.png)
![second hypothesis](/images/hypothesis2Combination of Primary and Highlight Color.png)
![third hypothesis](/images/hypothesis 3 Combination of Primary and Highlight Color.png)
![third hypothesis2](/images/hypothesis3 relation betwenn hectare and primary fur color.png)

For all the charts mark line is used. For third question besides mark line channel color hue is used. Channel length (1-d size) is used in all charts
for the measurement.
