# Your answer for Task 2: Why
1) Whats the highest frequency primary fur color and Highlight fur colors.       
2)Whats the highest frequency Combination of Primary and Highlight Color.
3)Relation between number of squrriel hectare number and fur colors to obtain which one grows more-
 - while in isolation and which grows more with other squrriels.