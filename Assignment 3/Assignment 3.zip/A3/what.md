# Your answer for Task 1: What

The given data is position data having the sampling and givingth the location in space and time.

Attribute types
Sno   Attribute name			Attribute type          Attribute range 
1	  Shift						Ctegorical data		    [AM and PM]		
2	  Age						Ordinal data			[nan, 'Adult', 'Juvenile', '?']
3     Date						Quantitative data		[10062018 to 10202018]	
4	  Primary Fur Color			Categorical				[nan, 'Gray', 'Cinnamon', 'Black']					
5     Eating					Categorical				[False,  True] 
6     Hectare Squirrel Number   quantitative			Numbered from 1 to 22		 
7	  Unique Squirrel ID        Categorical				Has 3018 unique values		
